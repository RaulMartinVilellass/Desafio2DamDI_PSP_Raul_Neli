﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GymFleto
{
    /// <summary>
    /// Interaction logic for paginaPrincipal.xaml
    /// </summary>
    public partial class paginaPrincipal : Window
    {
        public paginaPrincipal()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            new inicioSesion { Owner = this }.ShowDialog();
        }

        private void AbrirTarifas(object sender, RoutedEventArgs e)
        {
            new Tarifas { Owner = this }.ShowDialog();
        }
    }
}