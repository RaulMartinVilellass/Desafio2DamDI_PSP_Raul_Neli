﻿using System.Windows;

namespace GymFleto
{
    public partial class areaClientes : Window
    {
        public areaClientes()
        {
            InitializeComponent();
        }

        private void Volver_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}