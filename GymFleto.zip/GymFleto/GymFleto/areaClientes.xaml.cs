﻿using System.Windows;

namespace GymFleto
{
    public partial class areaClientes : Window
    {
        public areaClientes()
        {
            InitializeComponent();
        }

        private void CalcularIMC_Click(object sender, RoutedEventArgs e)
        {
            GymFleto_2.IMC ventana = new GymFleto_2.IMC(
                textoUsuario.Text, cajaPeso.Text, cajaAltura.Text);
            ventana.Owner = this;
            ventana.ShowDialog();
        }

        private void Volver_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}