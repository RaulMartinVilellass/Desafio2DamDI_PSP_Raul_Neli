﻿using System.Windows;

namespace GymFleto
{
    public partial class inicioSesion : Window
    {
        public inicioSesion()
        {
            InitializeComponent();
        }

        private void Volver_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Registrarse_Click(object sender, RoutedEventArgs e)
        {
            registro ventana = new registro();
            ventana.Owner = this;
            ventana.ShowDialog();
        }
    }
}