﻿using System.Windows;

namespace GymFleto
{
    public partial class inicioSesion : Window
    {
        public inicioSesion()
        {
            InitializeComponent();
        }

        private void Volver_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Acceder_Click(object sender, RoutedEventArgs e)
        {
            // Acceso provisional para probar el área de clientes.
            areaClientes ventana = new areaClientes();
            ventana.Owner = this;
            ventana.ShowDialog();
        }

        private void Registrarse_Click(object sender, RoutedEventArgs e)
        {
            registro ventana = new registro();
            ventana.Owner = this;
            ventana.ShowDialog();
        }
    }
}