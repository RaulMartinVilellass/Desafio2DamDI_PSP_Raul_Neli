﻿using System.Windows;

namespace GymFleto
{
    public partial class registro : Window
    {
        public registro()
        {
            InitializeComponent();
        }

        private void Volver_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}