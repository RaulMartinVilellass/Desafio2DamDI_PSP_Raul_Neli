﻿using System.Windows;

namespace GymFleto
{
    public partial class Tarifas : Window
    {
        public Tarifas()
        {
            InitializeComponent();
        }

        private void Volver_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}