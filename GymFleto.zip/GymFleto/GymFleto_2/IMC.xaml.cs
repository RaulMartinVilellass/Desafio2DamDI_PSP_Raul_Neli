﻿
using System;
using System.Globalization;
using System.Windows;

namespace GymFleto_2
{
    public partial class IMC : Window
    {
        public IMC()
        {
            InitializeComponent();
            botonCalcular.IsEnabled = false;
        }

        private void botonCalcular_Click(
            object sender, RoutedEventArgs e)
        {
            // Leer los valores mostrados en la ventana.
            bool pesoValido = double.TryParse(
                cajaPeso.Text,
                NumberStyles.Float,
                CultureInfo.CurrentCulture,
                out double peso);

            bool alturaValida = double.TryParse(
                cajaAltura.Text,
                NumberStyles.Float,
                CultureInfo.CurrentCulture,
                out double alturaCm);

            // Comprobar que los datos sean válidos.
            if (!pesoValido || !alturaValida ||
                peso <= 0 || alturaCm <= 0)
            {
                MessageBox.Show(
                    "El peso y la altura deben ser números positivos.",
                    "Error de validación",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            // Convertir centímetros a metros.
            double alturaMetros = alturaCm / 100.0;

            // Calcular IMC.
            double imc = peso /
                (alturaMetros * alturaMetros);

            // Mostrar el resultado.
            textoImc.Text = imc.ToString("F2");

            // La clasificación se implementará
            // según las reglas acordadas.
            textoClasificacion.Text = "Pendiente de clasificar";
        }
    }
}
