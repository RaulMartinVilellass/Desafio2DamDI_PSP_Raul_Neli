using System;

namespace GymFleto_2.Models;

public class RegistroPeticion
{
    public string IdSolicitud { get; set; } = "";
    public DateTime FechaRecepcion { get; set; }
    public string TipoOperacion { get; set; } = "Calcular Panfletismo";
    public string EstadoFinal { get; set; } = "";
    public string ErrorTecnico { get; set; } = "";
}
