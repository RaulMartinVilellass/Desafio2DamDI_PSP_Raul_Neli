namespace GymFleto_2.Models;

public class RespuestaIMC
{
    public string IdSolicitud { get; set; } = "";
    public decimal? Imc { get; set; }
    public string Estado { get; set; } = "";
    public string Error { get; set; } = "";
}
