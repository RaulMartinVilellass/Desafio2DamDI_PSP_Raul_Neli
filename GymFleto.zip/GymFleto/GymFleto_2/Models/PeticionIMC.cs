namespace GymFleto_2.Models;

public class PeticionIMC
{
    public string IdSolicitud { get; set; } = "";
    public int IdSocio { get; set; }
    public decimal PesoKg { get; set; }
    public decimal AlturaCm { get; set; }
}
