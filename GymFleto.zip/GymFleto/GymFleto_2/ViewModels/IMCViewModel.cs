using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using GymFleto_2.Models;

namespace GymFleto_2.ViewModels;

public class IMCViewModel : INotifyPropertyChanged
{
    private string resultadoIMC = "—";

    public ObservableCollection<RegistroPeticion> Peticiones { get; } = new();

    public string ResultadoIMC
    {
        get => resultadoIMC;
        set
        {
            resultadoIMC = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ResultadoIMC)));
        }
    }

    public event PropertyChangedEventHandler? PropertyChanged;
}
