namespace GymFleto_2.Services;

public class NamedPipeServer
{
    public string NombreTuberia { get; } = "GymFletoPipe";
}
