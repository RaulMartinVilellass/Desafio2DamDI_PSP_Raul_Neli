using System;

namespace GymFleto_2.Services;

public class CalculadoraIMC
{
    public decimal Calcular(decimal pesoKg, decimal alturaCm)
    {
        if (pesoKg <= 0 || alturaCm <= 0)
            throw new ArgumentException("Peso y altura deben ser positivos.");

        decimal alturaMetros = alturaCm / 100m;
        return Math.Round(pesoKg / (alturaMetros * alturaMetros), 2);
    }
}
