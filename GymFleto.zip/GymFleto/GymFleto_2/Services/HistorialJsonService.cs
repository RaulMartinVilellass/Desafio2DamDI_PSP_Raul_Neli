using System.Collections.Generic;
using GymFleto_2.Models;

namespace GymFleto_2.Services;

public class HistorialJsonService
{
    public string NombreArchivo { get; } = "historial.json";

    public List<RegistroPeticion> CrearHistorialVacio()
    {
        return new List<RegistroPeticion>();
    }
}
